from rest_framework import permissions
from .models import AllowedSuperAdmin

class SuperAdminEmailPermission(permissions.BasePermission):
    """
    Sirf dvorostores@gmail.com aur added super admins ko access deta hai.
    """
    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False
        
        user_email = request.user.email.lower()
        PRIMARY_ADMIN = "dvorostores@gmail.com"

        if user_email == PRIMARY_ADMIN:
            return True

        return AllowedSuperAdmin.objects.filter(email=user_email).exists()