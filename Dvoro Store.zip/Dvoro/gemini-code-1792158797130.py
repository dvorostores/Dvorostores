from rest_framework import views, status
from rest_framework.response import Response
from .permissions import SuperAdminEmailPermission
from .models import AllowedSuperAdmin
from apps.stores.models import Store

class ManageAdminEmailsView(views.APIView):
    permission_classes = [SuperAdminEmailPermission]

    def get(self, request):
        emails = list(AllowedSuperAdmin.objects.values_list('email', flat=True))
        if "dvorostores@gmail.com" not in emails:
            emails.insert(0, "dvorostores@gmail.com")
        return Response({'allowed_emails': emails})

    def post(self, request):
        email_to_add = request.data.get('email', '').strip().lower()
        if not email_to_add:
            return Response({'error': 'Email field is required'}, status=status.HTTP_400_BAD_REQUEST)

        AllowedSuperAdmin.objects.get_or_create(
            email=email_to_add,
            defaults={'added_by': request.user.email}
        )
        return Response({'message': f'{email_to_add} is now a Super Admin.'}, status=status.HTTP_201_CREATED)

class StoreControlView(views.APIView):
    permission_classes = [SuperAdminEmailPermission]

    def post(self, request, store_id):
        action = request.data.get('action') # 'PAUSE', 'BLOCK', 'ACTIVATE', 'FREE_STORE'
        store = Store.objects.get(id=store_id)

        if action == 'PAUSE':
            store.status = 'PAUSED'
        elif action == 'BLOCK':
            store.status = 'BLOCKED'
        elif action == 'ACTIVATE':
            store.status = 'ACTIVE'
        elif action == 'FREE_STORE':
            store.is_free = True

        store.save()
        return Response({'message': f'Store status updated to {action}'})